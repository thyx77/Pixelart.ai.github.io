import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Loader2, Download, Grid3X3, Heart, LogOut, LogIn } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

type Category = "cenario" | "objeto" | "personagem";
type Size = "32" | "64" | "128";
type Style = "fantasia" | "scifi" | "anime" | "medieval" | "cyberpunk" | "cartoon";
type Perspective = "frontal" | "lateral" | "isometrica" | "topdown";

interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  timestamp: Date;
}

interface Favorite {
  id: string;
  image_url: string;
  prompt: string;
  created_at: string;
}

export function PixelArtGenerator() {
  const { toast } = useToast();
  const { user, loading: authLoading, signOut } = useAuth();
  const navigate = useNavigate();
  
  const [prompt, setPrompt] = useState("");
  const [category, setCategory] = useState<Category>("personagem");
  const [size, setSize] = useState<Size>("64");
  const [style, setStyle] = useState<Style>("fantasia");
  const [perspective, setPerspective] = useState<Perspective>("frontal");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [gallery, setGallery] = useState<GeneratedImage[]>([]);
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [showFavorites, setShowFavorites] = useState(false);

  const categories: { value: Category; label: string; desc: string }[] = [
    { value: "cenario", label: "Cenário", desc: "Mapas, backgrounds" },
    { value: "objeto", label: "Objeto", desc: "Itens, armas" },
    { value: "personagem", label: "Personagem", desc: "Heróis, NPCs" },
  ];

  const sizes: { value: Size; label: string }[] = [
    { value: "32", label: "32×32" },
    { value: "64", label: "64×64" },
    { value: "128", label: "128×128" },
  ];

  const styles: { value: Style; label: string }[] = [
    { value: "fantasia", label: "Fantasia" },
    { value: "scifi", label: "Sci-Fi" },
    { value: "anime", label: "Anime" },
    { value: "medieval", label: "Medieval" },
    { value: "cyberpunk", label: "Cyberpunk" },
    { value: "cartoon", label: "Cartoon" },
  ];

  const perspectives: { value: Perspective; label: string }[] = [
    { value: "frontal", label: "Frontal" },
    { value: "lateral", label: "Lateral" },
    { value: "isometrica", label: "Isométrica" },
    { value: "topdown", label: "Top-Down" },
  ];

  const categoryTranslation: Record<Category, string> = {
    cenario: "scenery background landscape",
    objeto: "item object prop",
    personagem: "character sprite",
  };

  const perspectiveTranslation: Record<Perspective, string> = {
    frontal: "front view",
    lateral: "side view",
    isometrica: "isometric view",
    topdown: "top-down view",
  };

  useEffect(() => {
    if (user) {
      loadFavorites();
    }
  }, [user]);

  const loadFavorites = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from("favorites")
      .select("*")
      .order("created_at", { ascending: false });
    
    if (error) {
      console.error("Error loading favorites:", error);
      return;
    }
    
    setFavorites(data || []);
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Descrição necessária",
        description: "Por favor, descreva o que você quer gerar.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);

    try {
      const { data, error } = await supabase.functions.invoke('generate-pixel-art', {
        body: {
          prompt: `${categoryTranslation[category]}, ${prompt}`,
          category: category,
          size: `${size}x${size}`,
          style: style,
          perspective: perspectiveTranslation[perspective],
        },
      });

      if (error) {
        throw new Error(error.message);
      }

      if (data.error) {
        throw new Error(data.error);
      }

      const imageUrl = data.image;
      setGeneratedImage(imageUrl);

      const newImage: GeneratedImage = {
        id: Date.now().toString(),
        url: imageUrl,
        prompt: prompt,
        timestamp: new Date(),
      };
      setGallery((prev) => [newImage, ...prev].slice(0, 12));

      toast({
        title: "Imagem gerada",
        description: "Seu pixel art foi criado com sucesso.",
      });
    } catch (error) {
      console.error('Error generating pixel art:', error);
      toast({
        title: "Erro ao gerar",
        description: error instanceof Error ? error.message : "Ocorreu um erro inesperado.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveToFavorites = async () => {
    if (!user) {
      toast({
        title: "Login necessário",
        description: "Faça login para salvar favoritos.",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }

    if (!generatedImage) return;

    try {
      const { error } = await supabase.from("favorites").insert({
        user_id: user.id,
        image_url: generatedImage,
        prompt: prompt,
        category: category,
        style: style,
        size: size,
        perspective: perspective,
      });

      if (error) throw error;

      toast({
        title: "Salvo",
        description: "Imagem adicionada aos favoritos.",
      });
      
      loadFavorites();
    } catch (error) {
      console.error("Error saving favorite:", error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar o favorito.",
        variant: "destructive",
      });
    }
  };

  const handleRemoveFavorite = async (id: string) => {
    try {
      const { error } = await supabase.from("favorites").delete().eq("id", id);
      if (error) throw error;
      setFavorites((prev) => prev.filter((f) => f.id !== id));
      toast({ title: "Removido dos favoritos" });
    } catch (error) {
      console.error("Error removing favorite:", error);
    }
  };

  const handleDownload = () => {
    if (!generatedImage) return;
    const link = document.createElement("a");
    link.download = `pixelart-${Date.now()}.png`;
    link.href = generatedImage;
    link.click();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="mb-12">
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-3">
              <Grid3X3 className="h-8 w-8 text-foreground" />
              <h1 className="text-3xl font-bold tracking-tight text-foreground">
                Pixel Art AI
              </h1>
            </div>
            
            <div className="flex items-center gap-2">
              {!authLoading && (
                user ? (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowFavorites(!showFavorites)}
                      className="border-border"
                    >
                      <Heart className="h-4 w-4 mr-2" />
                      Favoritos ({favorites.length})
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={signOut}
                    >
                      <LogOut className="h-4 w-4" />
                    </Button>
                  </>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate("/auth")}
                    className="border-border"
                  >
                    <LogIn className="h-4 w-4 mr-2" />
                    Entrar
                  </Button>
                )
              )}
            </div>
          </div>
          <p className="text-muted-foreground max-w-md mt-2">
            Gere assets de pixel art para jogos usando inteligência artificial
          </p>
        </header>

        {/* Favorites Modal */}
        {showFavorites && (
          <div className="mb-8 rounded-lg border border-border bg-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-foreground">Seus Favoritos</h2>
              <Button variant="ghost" size="sm" onClick={() => setShowFavorites(false)}>
                Fechar
              </Button>
            </div>
            {favorites.length === 0 ? (
              <p className="text-muted-foreground text-sm">Nenhum favorito salvo ainda.</p>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                {favorites.map((fav) => (
                  <div key={fav.id} className="relative group">
                    <button
                      onClick={() => {
                        setGeneratedImage(fav.image_url);
                        setShowFavorites(false);
                      }}
                      className="aspect-square w-full rounded-md border border-border bg-muted overflow-hidden hover:border-foreground transition-colors"
                    >
                      <img
                        src={fav.image_url}
                        alt={fav.prompt}
                        className="w-full h-full object-contain"
                        style={{ imageRendering: "pixelated" }}
                      />
                    </button>
                    <button
                      onClick={() => handleRemoveFavorite(fav.id)}
                      className="absolute top-1 right-1 p-1 bg-background/80 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Heart className="h-3 w-3 fill-destructive text-destructive" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="grid lg:grid-cols-[360px_1fr] gap-8">
          {/* Sidebar - Controls */}
          <aside className="space-y-6">
            {/* Prompt Input */}
            <div className="space-y-2">
              <Label htmlFor="prompt" className="text-sm font-medium text-foreground">
                Descrição
              </Label>
              <Textarea
                id="prompt"
                placeholder="Descreva o que você quer gerar..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value.slice(0, 500))}
                className="min-h-[100px] bg-card border-border text-foreground placeholder:text-muted-foreground resize-none"
              />
              <p className="text-xs text-muted-foreground text-right">
                {prompt.length}/500
              </p>
            </div>

            {/* Category */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground">Categoria</Label>
              <RadioGroup
                value={category}
                onValueChange={(v) => setCategory(v as Category)}
                className="grid grid-cols-3 gap-2"
              >
                {categories.map((cat) => (
                  <div key={cat.value}>
                    <RadioGroupItem
                      value={cat.value}
                      id={cat.value}
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor={cat.value}
                      className="flex flex-col items-center justify-center rounded-md border border-border bg-card p-3 hover:bg-accent cursor-pointer peer-data-[state=checked]:border-foreground peer-data-[state=checked]:bg-secondary transition-colors"
                    >
                      <span className="text-sm font-medium text-foreground">{cat.label}</span>
                      <span className="text-xs text-muted-foreground">{cat.desc}</span>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            {/* Size */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground">Tamanho</Label>
              <RadioGroup
                value={size}
                onValueChange={(v) => setSize(v as Size)}
                className="grid grid-cols-3 gap-2"
              >
                {sizes.map((s) => (
                  <div key={s.value}>
                    <RadioGroupItem
                      value={s.value}
                      id={`size-${s.value}`}
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor={`size-${s.value}`}
                      className="flex items-center justify-center rounded-md border border-border bg-card p-3 hover:bg-accent cursor-pointer peer-data-[state=checked]:border-foreground peer-data-[state=checked]:bg-secondary transition-colors text-sm font-medium text-foreground"
                    >
                      {s.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            {/* Style */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground">Estilo</Label>
              <RadioGroup
                value={style}
                onValueChange={(v) => setStyle(v as Style)}
                className="grid grid-cols-3 gap-2"
              >
                {styles.map((s) => (
                  <div key={s.value}>
                    <RadioGroupItem
                      value={s.value}
                      id={`style-${s.value}`}
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor={`style-${s.value}`}
                      className="flex items-center justify-center rounded-md border border-border bg-card p-3 hover:bg-accent cursor-pointer peer-data-[state=checked]:border-foreground peer-data-[state=checked]:bg-secondary transition-colors text-sm font-medium text-foreground"
                    >
                      {s.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            {/* Perspective */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground">Perspectiva</Label>
              <RadioGroup
                value={perspective}
                onValueChange={(v) => setPerspective(v as Perspective)}
                className="grid grid-cols-2 gap-2"
              >
                {perspectives.map((p) => (
                  <div key={p.value}>
                    <RadioGroupItem
                      value={p.value}
                      id={`perspective-${p.value}`}
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor={`perspective-${p.value}`}
                      className="flex items-center justify-center rounded-md border border-border bg-card p-3 hover:bg-accent cursor-pointer peer-data-[state=checked]:border-foreground peer-data-[state=checked]:bg-secondary transition-colors text-sm font-medium text-foreground"
                    >
                      {p.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            {/* Generate Button */}
            <Button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full h-12 bg-primary text-primary-foreground hover:bg-primary/90 font-medium"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Gerando...
                </>
              ) : (
                "Gerar Pixel Art"
              )}
            </Button>
          </aside>

          {/* Main Content - Preview & Gallery */}
          <main className="space-y-8">
            {/* Preview Area */}
            <div className="rounded-lg border border-border bg-card p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-medium text-foreground">Preview</h2>
                {generatedImage && (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleSaveToFavorites}
                      className="border-border text-foreground hover:bg-accent"
                    >
                      <Heart className="h-4 w-4 mr-2" />
                      Salvar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDownload}
                      className="border-border text-foreground hover:bg-accent"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                )}
              </div>

              <div className="aspect-square max-w-md mx-auto rounded-md border border-border bg-muted flex items-center justify-center overflow-hidden">
                {isGenerating ? (
                  <div className="flex flex-col items-center gap-3 text-muted-foreground">
                    <Loader2 className="h-8 w-8 animate-spin" />
                    <span className="text-sm">Gerando pixel art...</span>
                  </div>
                ) : generatedImage ? (
                  <img
                    src={generatedImage}
                    alt="Generated pixel art"
                    className="w-full h-full object-contain"
                    style={{ imageRendering: "pixelated" }}
                  />
                ) : (
                  <div className="flex flex-col items-center gap-3 text-muted-foreground">
                    <Grid3X3 className="h-12 w-12" />
                    <span className="text-sm">Sua imagem aparecerá aqui</span>
                  </div>
                )}
              </div>
            </div>

            {/* Gallery */}
            {gallery.length > 0 && (
              <div className="rounded-lg border border-border bg-card p-6">
                <h2 className="text-lg font-medium text-foreground mb-4">Galeria</h2>
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                  {gallery.map((img) => (
                    <button
                      key={img.id}
                      onClick={() => setGeneratedImage(img.url)}
                      className="aspect-square rounded-md border border-border bg-muted overflow-hidden hover:border-foreground transition-colors"
                    >
                      <img
                        src={img.url}
                        alt={img.prompt}
                        className="w-full h-full object-contain"
                        style={{ imageRendering: "pixelated" }}
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
