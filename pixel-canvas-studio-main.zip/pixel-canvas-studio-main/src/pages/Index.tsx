import { PixelArtGenerator } from "@/components/PixelArtGenerator";

const Index = () => {
  return <PixelArtGenerator />;
};

export default Index;
